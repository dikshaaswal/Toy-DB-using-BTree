#include<stdio.h>
#include<stdlib.h>

struct student {
	char enrollment_no[11];
	char name[30];
	char email[23];
	char course_code[4];
	char gender[2];
};

struct bTree {
	int min_degree;
	int root;
	int next_pos;
	int node_count;
};

struct node {
	int key_count;
	int is_leaf;
	int location_in_disk;
	struct student students[2 * T - 1];
	int children[2 * T];
};

int main()
{
	struct bTree *tree = NULL;
	FILE *fp = NULL;
	fp = fopen("btree.bin","r+");
	tree = (struct bTree *)malloc(sizeof(struct bTree));
	fseek(fp, 0, 0);
	fread(tree, sizeof(struct bTree), 1, fp);
	fclose(fp);

	printf("root : %d ", tree->root);
	
	return 0;
}
