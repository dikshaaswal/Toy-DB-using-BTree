#include<stdio.h>
#include<stdlib.h>
#define T 10

struct student {
	char enrollment_no[11];
	char name[30];
	char email[23];
	char course_code[4];
	char gender[2];
};

struct bTree {
	int min_degree;
	int root;
	int next_pos;
	int node_count;
};

struct node {
	int key_count;
	int is_leaf;
	int location_in_disk;
	struct student students[2 * T - 1];
	int children[2 * T];
};

void traverse(struct bTree *tree, int root)
{
	if(root == -1)
		return;
	
	struct node *to_print = (struct node *)malloc(sizeof(struct node));
	
	FILE *fp = fopen("stu.bin","r+");

	fseek(fp, root * sizeof(struct node), 0);
	fread(to_print, sizeof(struct node), 1, fp);

	
	fclose(fp);
	
	int i;
	printf("newnode\n\n\n");
	for(i = 0; i < to_print->key_count; i++)
		printf("roll number : %s \n",to_print->students[i].enrollment_no);
	for(i = 0; i < 2 * T; i++)
		traverse(tree, to_print->children[i]);
	
	free(to_print);
}

int main()
{
	struct bTree *tree = NULL;
	FILE *fp = NULL;
	fp = fopen("btree.bin","r+");
	tree = (struct bTree *)malloc(sizeof(struct bTree));
	fseek(fp, 0, 0);
	fread(tree, sizeof(struct bTree), 1, fp);
	fclose(fp);

	traverse(tree, tree->root);
	
	return 0;
}
