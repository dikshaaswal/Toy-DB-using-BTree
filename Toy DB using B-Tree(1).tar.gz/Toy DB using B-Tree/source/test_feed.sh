#!/bin/bash

gcc -o a btree.c
cat testcases.txt|./a

