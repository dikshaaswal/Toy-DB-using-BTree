#!/bin/bash

gcc -o a btree.c
./a

